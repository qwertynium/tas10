package vsu.cs.vega.logic;

public class Rectangeles {
	public Point point1;
	public Point point2;

	public Rectangeles(Point point1, Point point2) {
		this.point1 = point1;
		this.point2 = point2;
	}


}
